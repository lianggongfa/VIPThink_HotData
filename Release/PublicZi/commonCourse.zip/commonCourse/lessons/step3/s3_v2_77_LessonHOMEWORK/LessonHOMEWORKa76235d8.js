
(function(window,document,Laya){
	var __un=Laya.un,__uns=Laya.uns,__static=Laya.static,__class=Laya.class,__getset=Laya.getset,__newvec=Laya.__newvec;

	var Box=laya.ui.Box,ClassUtils=laya.utils.ClassUtils,Event=laya.events.Event,FontClip=laya.ui.FontClip;
	var Image=laya.ui.Image,KlBaseKeyboard=com.klzz.ui.custom.KeyBoard.KlBaseKeyboard,KlInputImage=com.klzz.ui.custom.KeyBoard.KlInputImage;
	var KlKeyboardEvent=com.klzz.ui.custom.KeyBoard.KlKeyboardEvent,KlView=com.klzz.ui.KlView,Label=laya.ui.Label;
	var ScaleButton=com.klzz.ui.custom.ScaleButton,View=laya.ui.View,VipThink=com.biz.VipThink;
//class GameXSZYs3v277
var GameXSZYs3v277=(function(){
	function GameXSZYs3v277(){
		VipThink.__init__();
		ClassUtils.regClass("view.GameXSZYs3v2773D1",view.MyKlView);
		ClassUtils.regClass("view.TestMatchingGame",view.TestMatchingGame);
		ClassUtils.regClass("view.TestKeyBoard",view.TestBaseKeyboard);
	}

	__class(GameXSZYs3v277,'GameXSZYs3v277');
	return GameXSZYs3v277;
})()


//class LessonHOMEWORK
var LessonHOMEWORK=(function(){
	function LessonHOMEWORK(){
		VipThink.__init__();
	}

	__class(LessonHOMEWORK,'LessonHOMEWORK');
	return LessonHOMEWORK;
})()


//class ui.game_xszy.Game1UI extends com.klzz.ui.KlView
var Game1UI=(function(_super){
	function Game1UI(){
		this.answerBox=null;
		this.answer1=null;
		this.answer2=null;
		this.answer3=null;
		this._keyboard2=null;
		Game1UI.__super.call(this);
	}

	__class(Game1UI,'ui.game_xszy.Game1UI',_super);
	var __proto=Game1UI.prototype;
	__proto.createChildren=function(){
		View.regComponent("KlView",KlView);
		View.regComponent("KlInputImage",KlInputImage);
		View.regComponent("KlBaseKeyboard",KlBaseKeyboard);
		_super.prototype.createChildren.call(this);
		this.createView(Game1UI.uiView);
	}

	Game1UI.uiView={"type":"KlView","props":{"width":1920,"height":1080},"child":[{"type":"Image","props":{"width":1920,"skin":"game_xszy/image/bg1.jpg","height":1080}},{"type":"Box","props":{"width":1920,"mouseThrough":true,"height":1080},"child":[{"type":"Image","props":{"y":540,"x":691,"skin":"game_xszy/image/a1.png"}},{"type":"Image","props":{"y":625,"x":844,"skin":"game_xszy/image/a4.png"}},{"type":"Image","props":{"y":528,"x":982,"skin":"game_xszy/image/a4.png","rotation":180}},{"type":"Image","props":{"y":378,"x":780,"skin":"game_xszy/image/a2.png"}},{"type":"Image","props":{"y":660,"x":910,"skin":"game_xszy/image/a2.png"}},{"type":"Image","props":{"y":520,"x":1223,"skin":"game_xszy/image/a2.png"}},{"type":"Image","props":{"y":355,"x":755,"skin":"game_xszy/image/a3.png"}},{"type":"Image","props":{"y":631,"x":889,"skin":"game_xszy/image/a3.png"}},{"type":"Image","props":{"y":500,"x":1196,"skin":"game_xszy/image/a3.png"}}]},{"type":"Box","props":{"width":1920,"var":"answerBox","name":"answerBox","mouseThrough":true,"height":1080},"child":[{"type":"KlInputImage","props":{"y":500,"x":847,"width":136,"var":"answer1","spaceX":0,"sheet":"0123456789","place":2,"pivotY":120,"pivotX":68,"name":"answer1","height":120,"fontClipSkin":"game_xszy/image/fontclip_num1.png","filterColor":"#ffff00","filterBlur":5,"contentType":1,"canSelected":"false","arrowDirection":2}},{"type":"KlInputImage","props":{"y":775,"x":981,"width":136,"var":"answer2","spaceX":0,"sheet":"0123456789","place":2,"pivotY":120,"pivotX":68,"name":"answer2","height":120,"fontClipSkin":"game_xszy/image/fontclip_num1.png","filterColor":"#ffff00","filterBlur":5,"contentType":1,"canSelected":"false","arrowDirection":1}},{"type":"KlInputImage","props":{"y":644,"x":1291,"width":136,"var":"answer3","spaceX":0,"sheet":"0123456789","place":2,"pivotY":120,"pivotX":68,"name":"answer3","height":120,"fontClipSkin":"game_xszy/image/fontclip_num1.png","filterColor":"#ffff00","filterBlur":5,"contentType":1,"canSelected":"false","arrowDirection":3}}]},{"type":"KlBaseKeyboard","props":{"y":703,"x":308,"var":"_keyboard2","pattern":15,"name":"_keyboard2","fixed":"false","colorType":2}}]};
	return Game1UI;
})(KlView)


//class ui.game_xszy.Game2UI extends com.klzz.ui.KlView
var Game2UI=(function(_super){
	function Game2UI(){
		this.answerBox=null;
		this.answer3=null;
		this._keyboard2=null;
		Game2UI.__super.call(this);
	}

	__class(Game2UI,'ui.game_xszy.Game2UI',_super);
	var __proto=Game2UI.prototype;
	__proto.createChildren=function(){
		View.regComponent("KlView",KlView);
		View.regComponent("KlInputImage",KlInputImage);
		View.regComponent("KlBaseKeyboard",KlBaseKeyboard);
		_super.prototype.createChildren.call(this);
		this.createView(Game2UI.uiView);
	}

	Game2UI.uiView={"type":"KlView","props":{"width":1920,"height":1080},"child":[{"type":"Image","props":{"y":0,"x":0,"width":1920,"skin":"game_xszy/image/bg1.jpg","height":1080}},{"type":"Box","props":{"y":0,"x":0,"width":1920,"mouseThrough":true,"height":1080},"child":[{"type":"Image","props":{"y":520,"x":1223,"skin":"game_xszy/image/a2.png"}},{"type":"Image","props":{"y":500,"x":1196,"skin":"game_xszy/image/a3.png"}},{"type":"Image","props":{"y":542,"x":670,"width":522,"skin":"game_xszy/image/a5.png","height":83}}]},{"type":"Box","props":{"y":0,"x":0,"width":1920,"var":"answerBox","name":"answerBox","mouseThrough":true,"height":1080},"child":[{"type":"KlInputImage","props":{"y":645,"x":1291,"width":136,"var":"answer3","spaceX":0,"sheet":"0123456789","place":2,"pivotY":120,"pivotX":68,"name":"answer3","height":120,"fontClipSkin":"game_xszy/image/fontclip_num1.png","filterColor":"#ffff00","filterBlur":5,"contentType":1,"canSelected":"false","arrowDirection":3}}]},{"type":"KlBaseKeyboard","props":{"y":703,"x":308,"var":"_keyboard2","pattern":15,"name":"_keyboard2","fixed":"false","colorType":2}}]};
	return Game2UI;
})(KlView)


//class ui.game_xszy.Game3UI extends com.klzz.ui.KlView
var Game3UI=(function(_super){
	function Game3UI(){
		this.showBox=null;
		this.answer1=null;
		this.answer2=null;
		this.selectBox=null;
		Game3UI.__super.call(this);
	}

	__class(Game3UI,'ui.game_xszy.Game3UI',_super);
	var __proto=Game3UI.prototype;
	__proto.createChildren=function(){
		View.regComponent("KlView",KlView);
		View.regComponent("ScaleButton",ScaleButton);
		_super.prototype.createChildren.call(this);
		this.createView(Game3UI.uiView);
	}

	Game3UI.uiView={"type":"KlView","props":{"width":1920,"height":1080},"child":[{"type":"Image","props":{"width":1920,"skin":"game_xszy/image/bg2.jpg","height":1080}},{"type":"Box","props":{"width":1920,"var":"showBox","name":"showBox","mouseThrough":true,"height":1080},"child":[{"type":"Image","props":{"y":429,"x":982,"width":716,"skin":"game_xszy/image/b4.png","height":107,"anchorY":0.5,"anchorX":0.5},"child":[{"type":"Image","props":{"y":54,"x":358,"width":716,"visible":false,"var":"answer1","skin":"game_xszy/image/b3.png","name":"answer1","height":107,"anchorY":0.5,"anchorX":0.5}},{"type":"Image","props":{"y":20,"x":103,"skin":"game_xszy/image/b2.png"}}]},{"type":"Image","props":{"y":629,"x":982,"width":716,"skin":"game_xszy/image/b4.png","height":107,"anchorY":0.5,"anchorX":0.5},"child":[{"type":"Image","props":{"y":54,"x":358,"width":716,"visible":false,"var":"answer2","skin":"game_xszy/image/b3.png","name":"answer2","height":107,"anchorY":0.5,"anchorX":0.5}},{"type":"Image","props":{"y":22,"x":167,"skin":"game_xszy/image/b1.png"}}]}]},{"type":"Box","props":{"width":1920,"var":"selectBox","name":"selectBox","mouseThrough":true,"height":1080},"child":[{"type":"ScaleButton","props":{"y":373,"x":615,"width":730,"label":"","height":108}},{"type":"ScaleButton","props":{"y":574,"x":615,"width":730,"label":"","height":108}}]}]};
	return Game3UI;
})(KlView)


//class ui.game_xszy.Game4UI extends com.klzz.ui.KlView
var Game4UI=(function(_super){
	function Game4UI(){
		this.showBox=null;
		this.answer1=null;
		this.answer2=null;
		this.answer3=null;
		this.selectBox=null;
		Game4UI.__super.call(this);
	}

	__class(Game4UI,'ui.game_xszy.Game4UI',_super);
	var __proto=Game4UI.prototype;
	__proto.createChildren=function(){
		View.regComponent("KlView",KlView);
		View.regComponent("ScaleButton",ScaleButton);
		_super.prototype.createChildren.call(this);
		this.createView(Game4UI.uiView);
	}

	Game4UI.uiView={"type":"KlView","props":{"width":1920,"height":1080},"child":[{"type":"Image","props":{"width":1920,"skin":"game_xszy/image/bg3.jpg","height":1080}},{"type":"Image","props":{"y":476,"x":623,"width":678,"skin":"game_xszy/image/c1.png","height":74}},{"type":"Box","props":{"width":1920,"var":"showBox","name":"showBox","mouseThrough":true,"height":1080},"child":[{"type":"Image","props":{"y":931,"x":383,"skin":"game_xszy/image/c3.png","anchorY":0.5,"anchorX":0.5},"child":[{"type":"Image","props":{"y":39,"x":116,"visible":false,"var":"answer1","skin":"game_xszy/image/c2.png","name":"answer1","anchorY":0.5,"anchorX":0.5}},{"type":"Text","props":{"y":7,"x":64,"text":"A.23","fontSize":45,"font":"Microsoft YaHei","color":"#fbfbfb","bold":true,"align":"center"}}]},{"type":"Image","props":{"y":931,"x":963,"skin":"game_xszy/image/c3.png","anchorY":0.5,"anchorX":0.5},"child":[{"type":"Image","props":{"y":39,"x":116,"visible":false,"var":"answer2","skin":"game_xszy/image/c2.png","name":"answer2","anchorY":0.5,"anchorX":0.5}},{"type":"Text","props":{"y":7,"x":68,"text":"B.30","fontSize":45,"font":"Microsoft YaHei","color":"#fbfbfb","bold":true,"align":"center"}}]},{"type":"Image","props":{"y":931,"x":1543,"skin":"game_xszy/image/c3.png","anchorY":0.5,"anchorX":0.5},"child":[{"type":"Image","props":{"y":39,"x":116,"visible":false,"var":"answer3","skin":"game_xszy/image/c2.png","name":"answer3","anchorY":0.5,"anchorX":0.5}},{"type":"Text","props":{"y":7,"x":67,"text":"C.43","fontSize":45,"font":"Microsoft YaHei","color":"#fbfbfb","bold":true,"align":"center"}}]}]},{"type":"Box","props":{"width":1920,"var":"selectBox","name":"selectBox","mouseThrough":true,"height":1080},"child":[{"type":"ScaleButton","props":{"y":884,"x":260,"width":245,"label":"","height":90}},{"type":"ScaleButton","props":{"y":886,"x":837,"width":245,"label":"","height":90}},{"type":"ScaleButton","props":{"y":886,"x":1418,"width":245,"label":"","height":90}}]}]};
	return Game4UI;
})(KlView)


//class ui.game_xszy.Game5UI extends com.klzz.ui.KlView
var Game5UI=(function(_super){
	function Game5UI(){
		this.answerBox=null;
		this.answer1=null;
		this.answer2=null;
		this.answer3=null;
		this.answer4=null;
		this._keyboard2=null;
		Game5UI.__super.call(this);
	}

	__class(Game5UI,'ui.game_xszy.Game5UI',_super);
	var __proto=Game5UI.prototype;
	__proto.createChildren=function(){
		View.regComponent("KlView",KlView);
		View.regComponent("KlInputImage",KlInputImage);
		View.regComponent("KlBaseKeyboard",KlBaseKeyboard);
		_super.prototype.createChildren.call(this);
		this.createView(Game5UI.uiView);
	}

	Game5UI.uiView={"type":"KlView","props":{"width":1920,"height":1080},"child":[{"type":"Image","props":{"width":1920,"skin":"game_xszy/image/bg4.jpg","height":1080}},{"type":"Box","props":{"width":1920,"mouseThrough":true,"height":1080},"child":[{"type":"Image","props":{"y":458,"x":318,"skin":"game_xszy/image/d3.png"}},{"type":"Image","props":{"y":458,"x":396,"skin":"game_xszy/image/d3.png"}},{"type":"Image","props":{"y":458,"x":473,"skin":"game_xszy/image/d3.png"}},{"type":"Image","props":{"y":532,"x":356,"skin":"game_xszy/image/d3.png"}},{"type":"Image","props":{"y":532,"x":434,"skin":"game_xszy/image/d3.png"}},{"type":"Image","props":{"y":486,"x":885,"skin":"game_xszy/image/d3.png"}},{"type":"Image","props":{"y":486,"x":965,"skin":"game_xszy/image/d3.png"}},{"type":"Image","props":{"y":458,"x":1344,"skin":"game_xszy/image/d3.png"}},{"type":"Image","props":{"y":458,"x":1421,"skin":"game_xszy/image/d3.png"}},{"type":"Image","props":{"y":458,"x":1501,"skin":"game_xszy/image/d3.png"}},{"type":"Image","props":{"y":458,"x":1580,"skin":"game_xszy/image/d3.png"}},{"type":"Image","props":{"y":532,"x":1344,"skin":"game_xszy/image/d3.png"}},{"type":"Image","props":{"y":532,"x":1421,"skin":"game_xszy/image/d3.png"}},{"type":"Image","props":{"y":532,"x":1501,"skin":"game_xszy/image/d3.png"}},{"type":"Image","props":{"y":532,"x":1580,"skin":"game_xszy/image/d3.png"}},{"type":"Image","props":{"y":798,"x":581,"skin":"game_xszy/image/d4.png"}},{"type":"Image","props":{"y":798,"x":794,"skin":"game_xszy/image/d4.png"}},{"type":"Image","props":{"y":798,"x":1007,"skin":"game_xszy/image/d4.png"}},{"type":"Image","props":{"y":798,"x":1227,"skin":"game_xszy/image/d4.png"}},{"type":"Image","props":{"y":856,"x":751,"skin":"game_xszy/image/d1.png"}},{"type":"Image","props":{"y":856,"x":967,"skin":"game_xszy/image/d1.png"}},{"type":"Image","props":{"y":864,"x":1180,"skin":"game_xszy/image/d2.png"}}]},{"type":"Box","props":{"y":0,"x":0,"width":1920,"var":"answerBox","name":"answerBox","mouseThrough":true,"height":1080},"child":[{"type":"KlInputImage","props":{"y":938,"x":671,"width":136,"var":"answer1","spaceX":0,"sheet":"0123456789","place":2,"pivotY":120,"pivotX":68,"name":"answer1","height":120,"fontClipSkin":"game_xszy/image/fontclip_num1.png","filterColor":"#ffff00","filterBlur":5,"contentType":1,"canSelected":"false","arrowDirection":2}},{"type":"KlInputImage","props":{"y":938,"x":884,"width":136,"var":"answer2","spaceX":0,"sheet":"0123456789","place":2,"pivotY":120,"pivotX":68,"name":"answer2","height":120,"fontClipSkin":"game_xszy/image/fontclip_num1.png","filterColor":"#ffff00","filterBlur":5,"contentType":1,"canSelected":"false","arrowDirection":2}},{"type":"KlInputImage","props":{"y":938,"x":1097,"width":136,"var":"answer3","spaceX":0,"sheet":"0123456789","place":2,"pivotY":120,"pivotX":68,"name":"answer3","height":120,"fontClipSkin":"game_xszy/image/fontclip_num1.png","filterColor":"#ffff00","filterBlur":5,"contentType":1,"canSelected":"false","arrowDirection":2}},{"type":"KlInputImage","props":{"y":938,"x":1317,"width":136,"var":"answer4","spaceX":0,"sheet":"0123456789","place":2,"pivotY":120,"pivotX":68,"name":"answer4","height":120,"fontClipSkin":"game_xszy/image/fontclip_num1.png","filterColor":"#ffff00","filterBlur":5,"contentType":1,"canSelected":"false","arrowDirection":2}}]},{"type":"KlBaseKeyboard","props":{"y":703,"x":308,"var":"_keyboard2","pattern":15,"name":"_keyboard2","fixed":"false","colorType":2}}]};
	return Game5UI;
})(KlView)


//class ui.game_xszy.Game6UI extends com.klzz.ui.KlView
var Game6UI=(function(_super){
	function Game6UI(){
		this.showBox=null;
		this.jiaBtn=null;
		this.jianBtn=null;
		this.answerBox=null;
		this.answer1=null;
		this.answer2=null;
		this.answer3=null;
		this.answer4=null;
		this._keyboard2=null;
		Game6UI.__super.call(this);
	}

	__class(Game6UI,'ui.game_xszy.Game6UI',_super);
	var __proto=Game6UI.prototype;
	__proto.createChildren=function(){
		View.regComponent("KlView",KlView);
		View.regComponent("ScaleButton",ScaleButton);
		View.regComponent("KlInputImage",KlInputImage);
		View.regComponent("KlBaseKeyboard",KlBaseKeyboard);
		_super.prototype.createChildren.call(this);
		this.createView(Game6UI.uiView);
	}

	Game6UI.uiView={"type":"KlView","props":{"width":1920,"height":1080},"child":[{"type":"Image","props":{"width":1920,"skin":"game_xszy/image/bg5.jpg","height":1080}},{"type":"Box","props":{"y":0,"x":0,"width":1920,"mouseThrough":true,"height":1080},"child":[{"type":"Image","props":{"y":798,"x":581,"skin":"game_xszy/image/d4.png"}},{"type":"Image","props":{"y":798,"x":794,"skin":"game_xszy/image/d4.png"}},{"type":"Image","props":{"y":798,"x":1007,"skin":"game_xszy/image/d4.png"}},{"type":"Image","props":{"y":798,"x":1227,"skin":"game_xszy/image/d4.png"}},{"type":"Image","props":{"y":856,"x":751,"skin":"game_xszy/image/d1.png"}},{"type":"Image","props":{"y":856,"x":967,"skin":"game_xszy/image/d1.png"}},{"type":"Image","props":{"y":864,"x":1180,"skin":"game_xszy/image/d2.png"}},{"type":"Image","props":{"y":484,"x":316,"skin":"game_xszy/image/e3.png"}},{"type":"Image","props":{"y":484,"x":397,"skin":"game_xszy/image/e3.png"}},{"type":"Image","props":{"y":484,"x":478,"skin":"game_xszy/image/e3.png"}},{"type":"Image","props":{"y":541,"x":316,"skin":"game_xszy/image/e3.png"}},{"type":"Image","props":{"y":541,"x":397,"skin":"game_xszy/image/e3.png"}},{"type":"Image","props":{"y":541,"x":478,"skin":"game_xszy/image/e3.png"}},{"type":"Image","props":{"y":501,"x":847,"skin":"game_xszy/image/e3.png"}},{"type":"Image","props":{"y":501,"x":928,"skin":"game_xszy/image/e3.png"}},{"type":"Image","props":{"y":501,"x":1009,"skin":"game_xszy/image/e3.png"}}]},{"type":"Box","props":{"width":1920,"var":"showBox","name":"showBox","mouseThrough":true,"height":1080},"child":[{"type":"Image","props":{"y":485,"x":1419,"visible":false,"skin":"game_xszy/image/e3.png","anchorY":0.5,"anchorX":0.5}},{"type":"Image","props":{"y":485,"x":1499,"visible":false,"skin":"game_xszy/image/e3.png","anchorY":0.5,"anchorX":0.5}},{"type":"Image","props":{"y":485,"x":1579,"visible":false,"skin":"game_xszy/image/e3.png","anchorY":0.5,"anchorX":0.5}},{"type":"Image","props":{"y":535,"x":1419,"visible":false,"skin":"game_xszy/image/e3.png","anchorY":0.5,"anchorX":0.5}},{"type":"Image","props":{"y":535,"x":1499,"visible":false,"skin":"game_xszy/image/e3.png","anchorY":0.5,"anchorX":0.5}},{"type":"Image","props":{"y":535,"x":1579,"visible":false,"skin":"game_xszy/image/e3.png","anchorY":0.5,"anchorX":0.5}},{"type":"Image","props":{"y":585,"x":1419,"visible":false,"skin":"game_xszy/image/e3.png","anchorY":0.5,"anchorX":0.5}},{"type":"Image","props":{"y":585,"x":1499,"visible":false,"skin":"game_xszy/image/e3.png","anchorY":0.5,"anchorX":0.5}},{"type":"Image","props":{"y":585,"x":1579,"visible":false,"skin":"game_xszy/image/e3.png","anchorY":0.5,"anchorX":0.5}}]},{"type":"ScaleButton","props":{"y":677,"x":1402,"var":"jiaBtn","skin":"game_xszy/image/e2.png","name":"jiaBtn","label":""}},{"type":"ScaleButton","props":{"y":677,"x":1613,"var":"jianBtn","skin":"game_xszy/image/e1.png","name":"jianBtn","label":""}},{"type":"Box","props":{"y":0,"x":0,"width":1920,"var":"answerBox","name":"answerBox","mouseThrough":true,"height":1080},"child":[{"type":"KlInputImage","props":{"y":938,"x":671,"width":136,"var":"answer1","spaceX":0,"sheet":"0123456789","place":2,"pivotY":120,"pivotX":68,"name":"answer1","height":120,"fontClipSkin":"game_xszy/image/fontclip_num1.png","filterColor":"#ffff00","filterBlur":5,"contentType":1,"canSelected":"false","arrowDirection":2}},{"type":"KlInputImage","props":{"y":938,"x":884,"width":136,"var":"answer2","spaceX":0,"sheet":"0123456789","place":2,"pivotY":120,"pivotX":68,"name":"answer2","height":120,"fontClipSkin":"game_xszy/image/fontclip_num1.png","filterColor":"#ffff00","filterBlur":5,"contentType":1,"canSelected":"false","arrowDirection":2}},{"type":"KlInputImage","props":{"y":938,"x":1097,"width":136,"var":"answer3","spaceX":0,"sheet":"0123456789","place":2,"pivotY":120,"pivotX":68,"name":"answer3","height":120,"fontClipSkin":"game_xszy/image/fontclip_num1.png","filterColor":"#ffff00","filterBlur":5,"contentType":1,"canSelected":"false","arrowDirection":2}},{"type":"KlInputImage","props":{"y":938,"x":1317,"width":136,"var":"answer4","spaceX":0,"sheet":"0123456789","place":2,"pivotY":120,"pivotX":68,"name":"answer4","height":120,"fontClipSkin":"game_xszy/image/fontclip_num1.png","filterColor":"#ffff00","filterBlur":5,"contentType":1,"canSelected":"false","arrowDirection":2}}]},{"type":"KlBaseKeyboard","props":{"y":703,"x":308,"var":"_keyboard2","pattern":15,"name":"_keyboard2","fixed":"false","colorType":2}}]};
	return Game6UI;
})(KlView)


//class view.game_xszy.Game1 extends ui.game_xszy.Game1UI
var Game1=(function(_super){
	function Game1(){
		/**学生操作的时候，如果页面回到了最初什么都没做的时候一样，要把_result设置回null */
		this._result=null;
		Game1.__super.call(this);
	}

	__class(Game1,'view.game_xszy.Game1',_super);
	var __proto=Game1.prototype;
	Laya.imps(__proto,{"com.biz.ui.IHomeWorkOnline":true})
	__proto.labDesc=function(lab){
		lab.fontSize=40;
	}

	/**
	*【可不重写】
	*为控件添加侦听事件，不需要做卸载侦听事件的操作，在initView方法之前调用，切换关卡或者切换题目都会调用，点击重置的时候也会调用
	*/
	__proto.initialize=function(){
		var _$this=this;
		com.klzz.ui.KlView.prototype.initialize.call(this);
		this._keyboard2.on("klInputImageInput",this,function(kipi,campInputImages,allInputImages,keyboard){
			var num=kipi.getChildAt(0);
			num.scaleX=num.scaleY=1;
			if(kipi.fontClipValue.length==2 && kipi.fontClipValue.substr(0,1)=="0"){
				kipi.fontClipValue=kipi.fontClipValue.substr(1,1)
			}
			_$this.panduan();
		})
	}

	__proto.panduan=function(){
		var _num=0;
		var _num2=0;
		var _ary=["10","10","20"];
		for (var i=0;i < this.answerBox.numChildren;i++){
			var _answer=this.answerBox.getChildAt(i);
			if(_answer.fontClipValue==_ary[i]){
				_num2=_num2+1;
				}else if(_answer.fontClipValue=="" || _answer.fontClipValue==" " || _answer.fontClipValue==null){
				_num=_num+1;
			}
		}
		if(_num==3){
			this.result=null;
			}else if(_num2==3){
			this.result=true;
			}else{
			this.result=false;
		}
		console.log("答案为--------------"+this.result);
	}

	/**
	*【*需要重写*】
	*初始化界面，在initialize方法之后调用，切换关卡或者切换题目都会调用，点击重置的时候也会调用
	*/
	__proto.initView=function(byReset){
		(byReset===void 0)&& (byReset=false);
		com.klzz.ui.KlView.prototype.initView.call(this,byReset);
	}

	/**获取音效路径**/
	__getset(0,__proto,'sound',function(){
		return "game_xszy/sound/sound1.wav";
	});

	__getset(0,__proto,'result',function(){
		return this._result;
		},function(v){
		this._result=v;
	});

	/**获取问题描述**/
	__getset(0,__proto,'desc',function(){
		return "小朋友，计算下面算式，在方框中输入正确的数。";
	});

	return Game1;
})(Game1UI)


//class view.game_xszy.Game2 extends ui.game_xszy.Game2UI
var Game2=(function(_super){
	function Game2(){
		/**学生操作的时候，如果页面回到了最初什么都没做的时候一样，要把_result设置回null */
		this._result=null;
		Game2.__super.call(this);
	}

	__class(Game2,'view.game_xszy.Game2',_super);
	var __proto=Game2.prototype;
	Laya.imps(__proto,{"com.biz.ui.IHomeWorkOnline":true})
	__proto.labDesc=function(lab){
		lab.fontSize=40;
	}

	/**
	*【可不重写】
	*为控件添加侦听事件，不需要做卸载侦听事件的操作，在initView方法之前调用，切换关卡或者切换题目都会调用，点击重置的时候也会调用
	*/
	__proto.initialize=function(){
		var _$this=this;
		com.klzz.ui.KlView.prototype.initialize.call(this);
		this._keyboard2.on("klInputImageInput",this,function(kipi,campInputImages,allInputImages,keyboard){
			var num=kipi.getChildAt(0);
			num.scaleX=num.scaleY=1;
			if(kipi.fontClipValue.length==2 && kipi.fontClipValue.substr(0,1)=="0"){
				kipi.fontClipValue=kipi.fontClipValue.substr(1,1)
			}
			_$this.panduan();
		})
	}

	__proto.panduan=function(){
		var _num=0;
		var _num2=0;
		var _ary=["20"];
		for (var i=0;i < this.answerBox.numChildren;i++){
			var _answer=this.answerBox.getChildAt(i);
			if(_answer.fontClipValue==_ary[i]){
				_num2=_num2+1;
				}else if(_answer.fontClipValue=="" || _answer.fontClipValue==" " || _answer.fontClipValue==null){
				_num=_num+1;
			}
		}
		if(_num==1){
			this.result=null;
			}else if(_num2==1){
			this.result=true;
			}else{
			this.result=false;
		}
		console.log("答案为--------------"+this.result);
	}

	/**
	*【*需要重写*】
	*初始化界面，在initialize方法之后调用，切换关卡或者切换题目都会调用，点击重置的时候也会调用
	*/
	__proto.initView=function(byReset){
		(byReset===void 0)&& (byReset=false);
		com.klzz.ui.KlView.prototype.initView.call(this,byReset);
	}

	/**获取音效路径**/
	__getset(0,__proto,'sound',function(){
		return "game_xszy/sound/sound2.wav";
	});

	__getset(0,__proto,'result',function(){
		return this._result;
		},function(v){
		this._result=v;
	});

	/**获取问题描述**/
	__getset(0,__proto,'desc',function(){
		return "小朋友，计算下面算式，在方框中输入正确的数。";
	});

	return Game2;
})(Game2UI)


//class view.game_xszy.Game3 extends ui.game_xszy.Game3UI
var Game3=(function(_super){
	function Game3(){
		/**学生操作的时候，如果页面回到了最初什么都没做的时候一样，要把_result设置回null */
		this._result=null;
		Game3.__super.call(this);
	}

	__class(Game3,'view.game_xszy.Game3',_super);
	var __proto=Game3.prototype;
	Laya.imps(__proto,{"com.biz.ui.IHomeWorkOnline":true})
	__proto.labDesc=function(lab){
		lab.fontSize=40;
	}

	/**
	*【可不重写】
	*为控件添加侦听事件，不需要做卸载侦听事件的操作，在initView方法之前调用，切换关卡或者切换题目都会调用，点击重置的时候也会调用
	*/
	__proto.initialize=function(){
		com.klzz.ui.KlView.prototype.initialize.call(this);
		for (var i=0;i < this.selectBox.numChildren;i++){
			var _select=this.selectBox.getChildAt(i);
			_select.on("mousedown",this,this.selectFun,[i]);
		}
	}

	__proto.selectFun=function(_num){
		for (var i=0;i < this.showBox.numChildren;i++){
			var _show=this.showBox.getChildAt(i);
			var _img=_show.getChildAt(0);
			if(_num==i){
				_img.visible=!_img.visible;
				}else{
				_img.visible=false;
			}
		}
		this.panduan();
	}

	__proto.panduan=function(){
		if(!this.answer1.visible && !this.answer2.visible){
			this.result=null;
			}else if(this.answer2.visible){
			this.result=true;
			}else{
			this.result=false;
		}
		console.log("答案为--------------"+this.result);
	}

	/**
	*【*需要重写*】
	*初始化界面，在initialize方法之后调用，切换关卡或者切换题目都会调用，点击重置的时候也会调用
	*/
	__proto.initView=function(byReset){
		(byReset===void 0)&& (byReset=false);
		com.klzz.ui.KlView.prototype.initView.call(this,byReset);
	}

	/**获取音效路径**/
	__getset(0,__proto,'sound',function(){
		return "game_xszy/sound/sound3.wav";
	});

	__getset(0,__proto,'result',function(){
		return this._result;
		},function(v){
		this._result=v;
	});

	/**获取问题描述**/
	__getset(0,__proto,'desc',function(){
		return "小朋友，请你选出计算结果正确的算式。";
	});

	return Game3;
})(Game3UI)


//class view.game_xszy.Game4 extends ui.game_xszy.Game4UI
var Game4=(function(_super){
	function Game4(){
		/**学生操作的时候，如果页面回到了最初什么都没做的时候一样，要把_result设置回null */
		this._result=null;
		Game4.__super.call(this);
	}

	__class(Game4,'view.game_xszy.Game4',_super);
	var __proto=Game4.prototype;
	Laya.imps(__proto,{"com.biz.ui.IHomeWorkOnline":true})
	__proto.labDesc=function(lab){
		lab.fontSize=40;
	}

	/**
	*【可不重写】
	*为控件添加侦听事件，不需要做卸载侦听事件的操作，在initView方法之前调用，切换关卡或者切换题目都会调用，点击重置的时候也会调用
	*/
	__proto.initialize=function(){
		com.klzz.ui.KlView.prototype.initialize.call(this);
		for (var i=0;i < this.selectBox.numChildren;i++){
			var _select=this.selectBox.getChildAt(i);
			_select.on("mousedown",this,this.selectFun,[i]);
		}
	}

	__proto.selectFun=function(_num){
		for (var i=0;i < this.showBox.numChildren;i++){
			var _show=this.showBox.getChildAt(i);
			var _img=_show.getChildAt(0);
			if(_num==i){
				_img.visible=!_img.visible;
				}else{
				_img.visible=false;
			}
		}
		this.panduan();
	}

	__proto.panduan=function(){
		if(!this.answer1.visible && !this.answer2.visible && !this.answer3.visible){
			this.result=null;
			}else if(this.answer1.visible){
			this.result=true;
			}else{
			this.result=false;
		}
		console.log("答案为--------------"+this.result);
	}

	/**
	*【*需要重写*】
	*初始化界面，在initialize方法之后调用，切换关卡或者切换题目都会调用，点击重置的时候也会调用
	*/
	__proto.initView=function(byReset){
		(byReset===void 0)&& (byReset=false);
		com.klzz.ui.KlView.prototype.initView.call(this,byReset);
	}

	/**获取音效路径**/
	__getset(0,__proto,'sound',function(){
		return "game_xszy/sound/sound4.wav";
	});

	__getset(0,__proto,'result',function(){
		return this._result;
		},function(v){
		this._result=v;
	});

	/**获取问题描述**/
	__getset(0,__proto,'desc',function(){
		return "小朋友，请计算下面算式，选出正确的答案。";
	});

	return Game4;
})(Game4UI)


//class view.game_xszy.Game5 extends ui.game_xszy.Game5UI
var Game5=(function(_super){
	function Game5(){
		/**学生操作的时候，如果页面回到了最初什么都没做的时候一样，要把_result设置回null */
		this._result=null;
		Game5.__super.call(this);
	}

	__class(Game5,'view.game_xszy.Game5',_super);
	var __proto=Game5.prototype;
	Laya.imps(__proto,{"com.biz.ui.IHomeWorkOnline":true})
	__proto.labDesc=function(lab){
		lab.fontSize=40;
		lab.width=1000;
	}

	/**
	*【可不重写】
	*为控件添加侦听事件，不需要做卸载侦听事件的操作，在initView方法之前调用，切换关卡或者切换题目都会调用，点击重置的时候也会调用
	*/
	__proto.initialize=function(){
		var _$this=this;
		com.klzz.ui.KlView.prototype.initialize.call(this);
		this._keyboard2.on("klInputImageInput",this,function(kipi,campInputImages,allInputImages,keyboard){
			var num=kipi.getChildAt(0);
			num.scaleX=num.scaleY=1;
			if(kipi.fontClipValue.length==2 && kipi.fontClipValue.substr(0,1)=="0"){
				kipi.fontClipValue=kipi.fontClipValue.substr(1,1)
			}
			_$this.panduan();
		})
	}

	__proto.panduan=function(){
		var _num=0;
		var _num1=0;
		var _num2=0;
		var _num3=0;
		var _num4=0;
		for (var i=0;i < this.answerBox.numChildren;i++){
			var _answer=this.answerBox.getChildAt(i);
			if(_answer.fontClipValue=="5"){
				_num1=_num1+1;
				}else if(_answer.fontClipValue=="2"){
				_num2=_num2+1;
				}else if(_answer.fontClipValue=="8"){
				_num3=_num3+1;
				}else if(_answer.fontClipValue=="15" && _answer.name=="answer4"){
				_num4=_num4+1;
				}else if(_answer.fontClipValue=="" || _answer.fontClipValue==" " || _answer.fontClipValue==null){
				_num=_num+1;
			}
		}
		if(_num==4){
			this.result=null;
			}else if(_num1==1 && _num2==1 && _num3==1 && _num4==1){
			this.result=true;
			}else{
			this.result=false;
		}
		console.log("答案为--------------"+this.result);
	}

	/**
	*【*需要重写*】
	*初始化界面，在initialize方法之后调用，切换关卡或者切换题目都会调用，点击重置的时候也会调用
	*/
	__proto.initView=function(byReset){
		(byReset===void 0)&& (byReset=false);
		com.klzz.ui.KlView.prototype.initView.call(this,byReset);
	}

	/**获取音效路径**/
	__getset(0,__proto,'sound',function(){
		return "game_xszy/sound/sound5.wav";
	});

	__getset(0,__proto,'result',function(){
		return this._result;
		},function(v){
		this._result=v;
	});

	/**获取问题描述**/
	__getset(0,__proto,'desc',function(){
		return "观察下图，三位小伙伴一共有多少朵花呢？请列式并用凑十法计算。";
	});

	return Game5;
})(Game5UI)


//class view.game_xszy.Game6 extends ui.game_xszy.Game6UI
var Game6=(function(_super){
	function Game6(){
		/**学生操作的时候，如果页面回到了最初什么都没做的时候一样，要把_result设置回null */
		this._result=null;
		Game6.__super.call(this);
	}

	__class(Game6,'view.game_xszy.Game6',_super);
	var __proto=Game6.prototype;
	Laya.imps(__proto,{"com.biz.ui.IHomeWorkOnline":true})
	__proto.labDesc=function(lab){
		lab.fontSize=40;
	}

	/**
	*【可不重写】
	*为控件添加侦听事件，不需要做卸载侦听事件的操作，在initView方法之前调用，切换关卡或者切换题目都会调用，点击重置的时候也会调用
	*/
	__proto.initialize=function(){
		var _$this=this;
		com.klzz.ui.KlView.prototype.initialize.call(this);
		this._keyboard2.on("klInputImageInput",this,function(kipi,campInputImages,allInputImages,keyboard){
			var num=kipi.getChildAt(0);
			num.scaleX=num.scaleY=1;
			if(kipi.fontClipValue.length==2 && kipi.fontClipValue.substr(0,1)=="0"){
				kipi.fontClipValue=kipi.fontClipValue.substr(1,1)
			}
			_$this.panduan();
		})
		this.jiaBtn.on("click",this,this.jiaFun);
		this.jianBtn.on("click",this,this.jianFun);
	}

	__proto.jiaFun=function(_num){
		for (var i=0;i < this.showBox.numChildren;i++){
			var _show=this.showBox.getChildAt(i);
			if(!_show.visible){
				_show.visible=true;
				break ;
			}
		}
	}

	__proto.jianFun=function(_num){
		for (var i=this.showBox.numChildren-1;i >-1;i--){
			var _show=this.showBox.getChildAt(i);
			if(_show.visible){
				_show.visible=false;
				break ;
			}
		}
	}

	__proto.panduan=function(){
		var _num=0;
		var _num1=0;
		var _num2=0;
		var _num3=0;
		var _num4=0;
		for (var i=0;i < this.answerBox.numChildren;i++){
			var _answer=this.answerBox.getChildAt(i);
			if(_answer.fontClipValue=="3"){
				_num1=_num1+1;
				}else if(_answer.fontClipValue=="4"){
				_num2=_num2+1;
				}else if(_answer.fontClipValue=="6"){
				_num3=_num3+1;
				}else if(_answer.fontClipValue=="13" && _answer.name=="answer4"){
				_num4=_num4+1;
				}else if(_answer.fontClipValue=="" || _answer.fontClipValue==" " || _answer.fontClipValue==null){
				_num=_num+1;
			}
		}
		if(_num==4){
			this.result=null;
			}else if(_num1==1 && _num2==1 && _num3==1 && _num4==1){
			this.result=true;
			}else{
			this.result=false;
		}
		console.log("答案为--------------"+this.result);
	}

	/**
	*【*需要重写*】
	*初始化界面，在initialize方法之后调用，切换关卡或者切换题目都会调用，点击重置的时候也会调用
	*/
	__proto.initView=function(byReset){
		(byReset===void 0)&& (byReset=false);
		com.klzz.ui.KlView.prototype.initView.call(this,byReset);
	}

	/**获取音效路径**/
	__getset(0,__proto,'sound',function(){
		return "game_xszy/sound/sound6.wav";
	});

	__getset(0,__proto,'result',function(){
		return this._result;
		},function(v){
		this._result=v;
	});

	/**获取问题描述**/
	__getset(0,__proto,'desc',function(){
		return "观察下图，眯眯猫比皮皮虎多一块饼干，三位小伙伴一共有多少块饼干呢？请列式并用凑十法计算。";
	});

	return Game6;
})(Game6UI)



})(window,document,Laya);

if (typeof define === 'function' && define.amd){
	define('laya.core', ['require', "exports"], function(require, exports) {
        'use strict';
        Object.defineProperty(exports, '__esModule', { value: true });
        for (var i in Laya) {
			var o = Laya[i];
            o && o.__isclass && (exports[i] = o);
        }
    });
}
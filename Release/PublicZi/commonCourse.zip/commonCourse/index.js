/**
 * 设置LayaNative屏幕方向，可设置以下值
 * landscape           横屏
 * portrait            竖屏
 * sensor_landscape    横屏(双方向)
 * sensor_portrait     竖屏(双方向)
 */
window.screenOrientation = "sensor_landscape";
loadLib("libs/laya.physics3D0b89b83d.js")
loadLib("GameLoader2.maxb18c2604.js");
//-----libs-begin-----

//-----libs-end-------
// loadLib("libs/box2d2a9f51d3
